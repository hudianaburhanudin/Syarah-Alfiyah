# Status Pembahasan

| Nomor | Bait | Status |
|-------|------|--------|
| 1-80 | - | Selesai (di Word), diperkaya setelah Jilid 1 rampung |
| 81 | | Templat |
| 82 | | Templat |
| 83 | | Templat |
| 84 | | Templat |
| 85 | | Templat |
