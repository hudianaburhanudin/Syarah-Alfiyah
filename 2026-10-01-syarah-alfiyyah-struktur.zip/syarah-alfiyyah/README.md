# Syarah Alfiyyah Ibnu Malik

Syarah Alfiyyah berbahasa Indonesia, format akhir Word A5 siap cetak.

## Cara kerja
- Unit penulisan: satu **Pembahasan** (satu kaidah, 1-3 bait), bukan per bab.
- Satu Pembahasan = satu file `.md` di folder jilid.
- Pembahasan 1-80 sudah jadi (di Word) dan tidak ditulis ulang; diperkaya setelah Jilid 1 rampung.
- Rubrik penulisan: `00-panduan/2026-10-01-rubrik-ilmiyyah.md`.
- Rujukan: `00-panduan/2026-10-01-daftar-rujukan.md`.
- OCR hanya untuk mencari halaman; teks Arab berharakat dibaca dari gambar halaman.
- Status per Pembahasan: `02-catatan/2026-10-01-status-pembahasan.md`.
