# Daftar Rujukan

## Syarah utama
- Ibnu Aqil
- Asymuni
- Kawakib ad-Durriyyah
- Makkudi
- Awdhah al-Masalik
- Tashil al-Masalik

## Hasyiyah
- Shabban
- Khudhari
- Sujai

Catatan: semua berupa koleksi PDF. Tulis nama file PDF dan nomor halaman di tiap Pembahasan.
