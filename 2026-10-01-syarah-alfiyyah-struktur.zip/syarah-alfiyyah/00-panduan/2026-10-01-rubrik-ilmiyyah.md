# Rubrik Ilmiyyah Syarah Alfiyyah (10 bagian, versi nahwu)

> TEMPAT PENGGANTI. Tempel isi rubrik 10 bagian yang disusun 2026-09-12
> (file: 2026-09-12-rubrik-ilmiyyah-syarah-alfiyyah.md) di bawah ini.

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
